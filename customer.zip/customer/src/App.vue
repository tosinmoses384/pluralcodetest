<template lang="html">
  <router-view/>
</template>

<script>

export default {
  name: 'app',
  components: {
  },
  data () {
    return {
    }
  }
}
</script>

<style lang="scss">
 #app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  // text-align: center;
  // color: #2c3e50;
}

div i {
color:#fff;
}
</style>
