<template  src="./paymenthistory.html">
</template>

<script>
import navbarsidebar from '../../components/navbarsidebar.vue'
export default {
  name: 'paymenthistory',

  components: {
    navbarsidebar
  },
  data () {
    return {
    }
  }
}
</script>

<style scoped src="./paymenthistory.css">
</style>
