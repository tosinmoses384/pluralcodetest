import paymenthistory from './paymenthistory.vue'

export default paymenthistory
