import settings from './settings.vue'

export default settings
