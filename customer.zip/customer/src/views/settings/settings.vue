<template  src="./settings.html">
</template>

<script>
import navbarsidebar from '../../components/navbarsidebar.vue'
export default {
  name: 'settings',

  components: {
    navbarsidebar
  },
  data () {
    return {
    }
  }
}
</script>

<style scoped src="./settings.css">
</style>
