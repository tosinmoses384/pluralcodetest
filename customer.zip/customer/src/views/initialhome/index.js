import initialhome from './initialhome.vue'

export default initialhome
