<template  src="./initialhome.html">
</template>

<script>

export default {
  name: 'initialhome',
  data () {
    return {
    }
  }
}
</script>

<style scoped src="./initialhome.css">
</style>
