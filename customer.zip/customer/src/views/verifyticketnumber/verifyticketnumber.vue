<template src="./verifyticketnumber.html">
</template>

<script>
import navbarsidebar from '../../components/navbarsidebar.vue'
export default {
  name: 'verifyticketnumber',

  components: {
    navbarsidebar
  },

  data () {
    return {
    }
  }
}
</script>

<style scoped src="./verifyticketnumber.css">
</style>
