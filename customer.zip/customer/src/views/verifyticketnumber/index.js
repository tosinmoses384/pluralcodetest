import verifyticketnumber from './verifyticketnumber.vue'

export default verifyticketnumber
