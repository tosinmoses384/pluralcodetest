<template  src="./login.html">
</template>

<script>

export default {
  name: 'login',
  data () {
    return {
    }
  }
}
</script>

<style scoped src="./login.css">
</style>
