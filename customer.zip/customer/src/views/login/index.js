import login from './login.vue'

export default login
