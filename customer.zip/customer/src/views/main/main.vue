<template  src="./main.html">
</template>

<script>

export default {
  name: 'main',
  data () {
    return {
    }
  }
}
</script>

<style scoped src="./main.css">
</style>
