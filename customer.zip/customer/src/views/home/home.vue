<template  src="./home.html">
</template>

<script>

export default {
  name: 'home',
  data () {
    return {
    }
  }
}
</script>

<style scoped src="./home.css">
</style>
