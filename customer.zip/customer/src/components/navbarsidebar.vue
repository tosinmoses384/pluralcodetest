<template>

<div class="father-container">

  <!-- %%%%%%%%%%%%%%%%
    SIDEBAR - SECTION
  %%%%%%%%%%%%%%% -->
  <div class="sidebar-div">

    <div class="image-div">
      <img class="banner" src="../assets/banner.png" alt="banner-img">
    </div>
    <!-- <div class="white-space"></div> -->

    <div class="menu-container">

      <div class="dashboard-h3-div only">
        <img src="../assets/Vector.png" alt="dashboard">
        <h3 class="dashboard-h3">Dashboard</h3>
      </div>

      <div class="verify-insurance-div">
        <img src="../assets/Vector_1.png" alt="verify-insurance">
        <h3 class="verify-insurance">Verify-Ticket</h3>
      </div>

      <div class="payment-history-div">
        <img src="../assets/Vector_2.png" alt="payment-history">
        <h3 class="payment-history">payment-History</h3>
      </div>

      <div class="settings-div">
        <img src="../assets/Vector_2.png" alt="settings">
        <h3 class="settings">Settings</h3>
      </div>

      <div class="records-div">
        <img src="../assets/Vector_3.png" alt="records">
        <h3 class="records">Records</h3>
        <img src="../assets/vector_4.png" alt="records-righticon" class="records-righticon">
      </div>

    </div>

    <div class="trips-payout-container">
      <h3 class="trips">Drivers</h3>
      <h3 class="payouts">Vehicles</h3>
      <h3 class="payouts">Ticket Staff</h3>
    </div>

    <div class="white-space">
      <div class="passprof">
        <b-icon-menu-button-wide></b-icon-menu-button-wide>
        <h3 class="passproof-h3">Passenger Profile</h3>
      </div>

      <div class="setupweb">
        <b-icon-menu-button-wide></b-icon-menu-button-wide>
        <h3 class="setupweb-h3">Setup Website</h3>
      </div>
    </div>

    <div class="logout">
      <h3-logout-div>logout</h3-logout-div>
    </div>

  </div>

  <!-- %%%%%%%%%%%%%%%%%%%
    MAIN - SECTION
  %%%%%%%%%%%%%%%%%% -->
  <div class="main-content-div">

    <div class="navigation-div">

      <!-- <b-icon-arrow-up></b-icon-arrow-up> -->

      <div class="toggle-div">
        <!-- <img src="../../assets/vector_5.png" alt="toggle" class="toggle">
        <img src="../../assets/vector_5.png" alt="toggle" class="toggle"> -->
        <!-- <i class="fa fa-bars" aria-hidden="true"></i> -->
        <b-icon-menu-button-wide></b-icon-menu-button-wide>
        <!-- <font-awesome-icon icon="faCat" /> -->

      </div>

      <div class="right-menu-div">
        <div class="bellwrapper">
         <img src="../assets/img6.png" alt="bell-div" class="bell-div">
         <div class="round-div">4</div>
        </div>

        <div class="bellwrapper">
          <img src="../assets/img4.png" alt="email-div" class="email-div">
          <div class="round-div">4</div>
         </div>
        <!-- <img src="../../assets/img4.png" alt="email-div" class="email-div"> -->
        <img src="../assets/Vector_8.png" alt="search-div" class="search-div">
        <img src="../assets/vector_9.png" alt="photo-div" class="photo-div">
        <div class="logout-botton">
          <h3 class="topmost-h">logout</h3>
        </div>
      </div>
    </div>

    <!-- %%%%%%%%%%%%%%%%
     INNER-MAIN-SECTION
    %%%%%%%%%%%%%%%% -->

  </div>

</div>

</template>

<script>

export default {
  name: 'navbarsidebar',
  data () {
    return {
    }
  }
}
</script>

<style>
.father-container {
    display: flex;
    flex-direction: row;
    background: #FFFFFF;
    box-shadow: 0px 4px 100px rgba(0, 0, 0, 0.25);
}

/* .father-container .image-div {
   border: 1px dashed red;
} */

.father-container .banner {
    width: 100%;
    height: 150px;
}

/* %%%%%%%%%%%%%%%%
SIDEBAR - SECTION
%%%%%%%%%%%%%%%  */
.father-container .sidebar-div {
    width: 15%;
    height: 100%;
    background: #FFFFFF;
    box-shadow: 40px 4px 100px rgba(159, 155, 155, 0.25);
}

/* .father-container .white-space {
    border: 1px dashed red;
} */

.father-container .menu-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding-left: 1rem;
    width: 100%!important;

}

.father-container .dashboard-h3-div,
.father-container .verify-insurance-div,
.father-container .payment-history-div,
.father-container .settings-div,
.father-container .records-div
 {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    width: 100%!important;
    padding-top:0;
    padding-right: 0.5rem;
    margin-top: 1rem;
}

.father-container .dashboard-h3,
.father-container .verify-insurance,
.father-container .payment-history,
.father-container .settings,
.father-container .records
{
    font-family: Ubuntu;
    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    color: #5B5B5B;
}

.father-container .only {
    background: #F3F3F3;
}

.father-container .trips-payout-container {
    display: flex;
    flex-direction: column;
    align-items: start;
    justify-content: center;
    margin-left: 2rem;
    width: 80%;
    background: #FFFFFF;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.14);
}

.father-container .trips,
.father-container .payouts {
    font-family: Ubuntu;
    font-style: normal;
    font-weight: 500;
    font-size: 12px;
    margin-bottom: 0px;
    padding-left: 0.5rem;
    color: #000000;

}

.father-container .white-space {
    height: 250px;
}

.father-container .passprof,
.father-container .setupweb {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    margin-top: 2rem;
}

.father-container .passproof-h3,
.father-container .setupweb-h3 {
    font-family: Ubuntu;
    font-style: normal;
    font-weight: 500;
    font-size: 14px;
    line-height: 23px;
    letter-spacing: 0.0257883px;
    color: #5B5B5B;

}

.father-container .logout {
    background: #D60026;
    border-radius: 4px;
    text-align: center;
    color: #fff;
}

    /* %%%%%%%%%%%%%%%%
     MAIN-SECTION
    %%%%%%%%%%%%%%%%  */
.father-container .main-content-div {
    display: flex;
    flex-direction: column;
    width: 90%;
    height: 100%;
    background: #FFFFFF;
    box-shadow: 0px 4px 100px rgba(0, 0, 0, 0.25);
}

.father-container .navigation-div {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    height: 80px;
    background: #063E9B;
    box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
    color: #fff;

}

.father-container .toggle-div {
    margin-left: 2rem;
    margin-bottom: 2rem;
    margin-top: 21px;
    width: 28px;
}

.father-container .right-menu-div {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    align-items: center;
    margin-right: 2rem;
    width: 30%;
}

.father-container .bellwrapper {
    position: relative;
}

.father-container .round-div {
    background-color: red;
    border-radius: 50%;
    position: absolute;
    top: -11px;
    right: -5px;
    border: 0;
    padding: 7px 6px;
    z-index: 2;
    font-family: Ubuntu;
    font-style: normal;
    font-weight: 500;
    font-size: 6px;
    text-align: center;
    color: #FFFFFF;
    height:0px;
    padding-bottom:19px
}

.father-container .logout-botton {
    background: #D82424;
    border-radius: 4px;
    padding: 0 14px;

}

.father-container .topmost-h {
    padding-top: 0.5rem;
    padding-left: 1.2rem;
    width: 90px;
    font-family: Ubuntu;
    font-style: normal;
    font-weight: bold;
    font-size: 14px;
    color: #FFFFFF;
}

.father-container .photo-div {
    width: 30px;
    height: 30px;
    border: 2px solid #FFFFFF;
    box-sizing: border-box;
    border: none;
}

.father-container .email-div,
.father-div .bell-div {
    background: #FFFFFF;
}

.father-container .plc-div {
    position: absolute;
    top: 0;
    left: 0px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    width: 20%;
    background: #D82424;
    border-radius: 4px;
    }

    .father-container .h3-plc {
        width: 100%;
        font-family: Ubuntu;
        font-style: normal;
        font-weight: bold;
        font-size: 14px;
        color: #FFFFFF;

    }

    .father-container .cover-div {
        width: 70%;
        background-color: red!important;
        box-shadow: 0px 4px 100px rgba(0, 0, 0, 0.25);

    }

    .father-container .fill-div {
        width: 100%;
        height: 100%;
        background: #FFFFFF;
        box-shadow: 40px 4px 100px rgba(159, 155, 155, 0.25);
    }
</style>
